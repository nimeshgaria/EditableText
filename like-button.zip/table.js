"use strict";

var _react = _interopRequireDefault(require("react"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }
function Table(props) {
  return /*#__PURE__*/_react["default"].createElement("h1", null, "Hello, ", props.name);
}